package com.campus.events;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartCampusEventsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SmartCampusEventsApplication.class, args);
    }
}

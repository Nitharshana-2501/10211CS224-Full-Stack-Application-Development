package com.campus.events.controller;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.campus.events.entity.Event;
import com.campus.events.service.EventService;
import com.campus.events.service.RegistrationService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private static final Logger logger = Logger.getLogger(AdminController.class.getName());

    @Autowired
    private EventService eventService;

    @Autowired
    private RegistrationService registrationService;

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("stats", eventService.getRegistrationStats());
        model.addAttribute("totalRegistrations", eventService.getTotalRegistrations());
        model.addAttribute("totalEvents", eventService.getTotalEvents());
        model.addAttribute("eventsByDepartment", eventService.getEventsByDepartment());
        return "admin/dashboard";
    }

    @GetMapping("/events")
    public String listEvents(
            @RequestParam(required = false) String department,
            @RequestParam(required = false) String date,
            Model model) {

        model.addAttribute("events", eventService.search(department, date, null));
        model.addAttribute("department", department);
        model.addAttribute("date", date);
        return "admin/event-list";
    }

    @GetMapping("/events/new")
    public String newEventForm(Model model) {
        model.addAttribute("event", new Event());
        model.addAttribute("eventTypes", Event.EventType.values());
        model.addAttribute("formAction", "/admin/events");
        model.addAttribute("pageTitle", "Create New Event");
        return "admin/event-form";
    }

    @PostMapping("/events")
    public String createEvent(
            @Valid @ModelAttribute("event") Event event,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("eventTypes", Event.EventType.values());
            model.addAttribute("formAction", "/admin/events");
            model.addAttribute("pageTitle", "Create New Event");
            return "admin/event-form";
        }

        eventService.save(event);
        redirectAttributes.addFlashAttribute("successMessage", "Event created successfully!");
        return "redirect:/admin/events";
    }

    @GetMapping("/events/{id}/edit")
    public String editEventForm(@PathVariable Long id, Model model) {
        model.addAttribute("event", eventService.findById(id));
        model.addAttribute("eventTypes", Event.EventType.values());
        model.addAttribute("formAction", "/admin/events/" + id);
        model.addAttribute("pageTitle", "Edit Event");
        return "admin/event-form";
    }

    @PostMapping("/events/{id}")
    public String updateEvent(
            @PathVariable Long id,
            @Valid @ModelAttribute("event") Event event,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("eventTypes", Event.EventType.values());
            model.addAttribute("formAction", "/admin/events/" + id);
            model.addAttribute("pageTitle", "Edit Event");
            return "admin/event-form";
        }

        eventService.update(id, event);
        redirectAttributes.addFlashAttribute("successMessage", "Event updated successfully!");
        return "redirect:/admin/events";
    }

    @PostMapping("/events/{id}/delete")
    public String deleteEvent(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        eventService.deleteById(id);
        redirectAttributes.addFlashAttribute("successMessage", "Event deleted successfully!");
        return "redirect:/admin/events";
    }

    @GetMapping("/events/{id}/registrations")
    public String viewRegistrations(@PathVariable Long id, Model model) {
        model.addAttribute("event", eventService.findById(id));
        model.addAttribute("registrations", registrationService.findByEventId(id));
        return "admin/registrations";
    }

    @PostMapping("/registrations/{regId}/cancel")
    public String cancelRegistration(
            @PathVariable Long regId,
            @RequestParam Long eventId,
            RedirectAttributes redirectAttributes) {

        registrationService.cancelRegistration(regId);
        redirectAttributes.addFlashAttribute("successMessage", "Registration cancelled.");
        return "redirect:/admin/events/" + eventId + "/registrations";
    }
}

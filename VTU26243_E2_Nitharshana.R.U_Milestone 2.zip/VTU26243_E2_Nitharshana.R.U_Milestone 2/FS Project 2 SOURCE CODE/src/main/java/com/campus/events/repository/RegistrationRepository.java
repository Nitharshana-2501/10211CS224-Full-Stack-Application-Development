package com.campus.events.repository;

import com.campus.events.entity.Registration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RegistrationRepository extends JpaRepository<Registration, Long> {

    /** All registrations for a specific event. */
    List<Registration> findByEventId(Long eventId);

    /** All registrations belonging to a student email. */
    List<Registration> findByStudentEmailIgnoreCase(String studentEmail);

    /** Check if a student is already registered for an event. */
    boolean existsByStudentEmailIgnoreCaseAndEventId(String studentEmail, Long eventId);

    /** Find a specific registration by email + event. */
    Optional<Registration> findByStudentEmailIgnoreCaseAndEventId(String studentEmail, Long eventId);

    /** Count registrations per event — used in dashboard stats. */
    @Query("SELECT r.event.id, COUNT(r) FROM Registration r GROUP BY r.event.id")
    List<Object[]> countRegistrationsGroupedByEvent();

    /** Total registrations for a single event. */
    @Query("SELECT COUNT(r) FROM Registration r WHERE r.event.id = :eventId")
    long countByEventId(@Param("eventId") Long eventId);
}

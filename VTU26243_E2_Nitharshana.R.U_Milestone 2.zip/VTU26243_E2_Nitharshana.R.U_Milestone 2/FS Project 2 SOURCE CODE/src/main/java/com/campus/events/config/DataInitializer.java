package com.campus.events.config;

import com.campus.events.entity.Event;
import com.campus.events.entity.Registration;
import com.campus.events.repository.EventRepository;
import com.campus.events.repository.RegistrationRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDateTime;
import java.util.logging.Logger;

@Configuration
public class DataInitializer {

    private static final Logger logger = Logger.getLogger(DataInitializer.class.getName());

    @Bean
    CommandLineRunner seedData(EventRepository eventRepo, RegistrationRepository regRepo) {
        return args -> {
            if (eventRepo.count() > 0) {
                logger.info("Database already seeded — skipping.");
                return;
            }

            logger.info("Seeding sample data...");

            Event e1 = new Event();
            e1.setTitle("AI & Machine Learning Seminar");
            e1.setDescription("Explore the latest trends in AI and ML with industry experts. Topics include deep learning, NLP, and computer vision.");
            e1.setDate(LocalDateTime.now().plusDays(10));
            e1.setLocation("Auditorium A, Block 1");
            e1.setDepartment("Computer Science");
            e1.setType(Event.EventType.SEMINAR);
            e1.setCapacity(200);
            e1 = eventRepo.save(e1);

            Event e2 = new Event();
            e2.setTitle("Spring Boot Workshop");
            e2.setDescription("Hands-on workshop covering Spring Boot 3.x, REST APIs, Spring Security, and JPA best practices.");
            e2.setDate(LocalDateTime.now().plusDays(15));
            e2.setLocation("Lab 301, Block 3");
            e2.setDepartment("Computer Science");
            e2.setType(Event.EventType.WORKSHOP);
            e2.setCapacity(50);
            e2 = eventRepo.save(e2);

            Event e3 = new Event();
            e3.setTitle("Annual Hackathon 2026");
            e3.setDescription("48-hour hackathon open to all students. Build innovative solutions for real-world problems. Prizes worth $5,000!");
            e3.setDate(LocalDateTime.now().plusDays(20));
            e3.setLocation("Innovation Hub, Block 5");
            e3.setDepartment("All Departments");
            e3.setType(Event.EventType.HACKATHON);
            e3.setCapacity(300);
            e3 = eventRepo.save(e3);

            Event e4 = new Event();
            e4.setTitle("Business Analytics Conference");
            e4.setDescription("Industry leaders discuss data-driven decision making, BI tools, and the future of business analytics.");
            e4.setDate(LocalDateTime.now().plusDays(25));
            e4.setLocation("Conference Hall B, Block 2");
            e4.setDepartment("Business Administration");
            e4.setType(Event.EventType.CONFERENCE);
            e4.setCapacity(150);
            e4 = eventRepo.save(e4);

            Event e5 = new Event();
            e5.setTitle("Cultural Fest 2026");
            e5.setDescription("Celebrate diversity with music, dance, art, and food from cultures around the world.");
            e5.setDate(LocalDateTime.now().plusDays(30));
            e5.setLocation("Main Campus Ground");
            e5.setDepartment("Student Affairs");
            e5.setType(Event.EventType.CULTURAL);
            e5.setCapacity(1000);
            e5 = eventRepo.save(e5);

            // Sample registrations
            Registration r1 = new Registration();
            r1.setStudentName("Alice Johnson");
            r1.setStudentEmail("alice@campus.edu");
            r1.setEvent(e1);
            regRepo.save(r1);

            Registration r2 = new Registration();
            r2.setStudentName("Bob Smith");
            r2.setStudentEmail("bob@campus.edu");
            r2.setEvent(e1);
            regRepo.save(r2);

            Registration r3 = new Registration();
            r3.setStudentName("Alice Johnson");
            r3.setStudentEmail("alice@campus.edu");
            r3.setEvent(e2);
            regRepo.save(r3);

            Registration r4 = new Registration();
            r4.setStudentName("Charlie Brown");
            r4.setStudentEmail("charlie@campus.edu");
            r4.setEvent(e3);
            regRepo.save(r4);

            Registration r5 = new Registration();
            r5.setStudentName("Diana Prince");
            r5.setStudentEmail("diana@campus.edu");
            r5.setEvent(e3);
            regRepo.save(r5);

            Registration r6 = new Registration();
            r6.setStudentName("Bob Smith");
            r6.setStudentEmail("bob@campus.edu");
            r6.setEvent(e4);
            regRepo.save(r6);

            logger.info("Seeded " + eventRepo.count() + " events and 6 registrations.");
        };
    }
}

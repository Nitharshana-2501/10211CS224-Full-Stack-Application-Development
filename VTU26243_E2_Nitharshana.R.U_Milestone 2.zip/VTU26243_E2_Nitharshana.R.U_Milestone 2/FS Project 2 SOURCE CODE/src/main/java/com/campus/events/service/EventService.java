package com.campus.events.service;

import com.campus.events.dto.EventStatsDto;
import com.campus.events.entity.Event;
import com.campus.events.exception.EventNotFoundException;
import com.campus.events.repository.EventRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

@Service
public class EventService {

    private static final Logger logger = Logger.getLogger(EventService.class.getName());

    @Autowired
    private EventRepository eventRepository;

    @Transactional(readOnly = true)
    public List<Event> findAll() {
        return eventRepository.findAll();
    }

    @Transactional(readOnly = true)
    public Event findById(Long id) {
        return eventRepository.findById(id)
                .orElseThrow(() -> new EventNotFoundException(id));
    }

    @Transactional
    public Event save(Event event) {
        logger.fine("Saving event: " + event.getTitle());
        return eventRepository.save(event);
    }

    @Transactional
    public Event update(Long id, Event updated) {
        Event existing = findById(id);
        existing.setTitle(updated.getTitle());
        existing.setDescription(updated.getDescription());
        existing.setDate(updated.getDate());
        existing.setLocation(updated.getLocation());
        existing.setDepartment(updated.getDepartment());
        existing.setType(updated.getType());
        existing.setCapacity(updated.getCapacity());
        return eventRepository.save(existing);
    }

    @Transactional
    public void deleteById(Long id) {
        if (!eventRepository.existsById(id)) {
            throw new EventNotFoundException(id);
        }
        eventRepository.deleteById(id);
    }

    @Transactional(readOnly = true)
    public List<Event> search(String department, String dateStr, String keyword) {
        boolean hasKeyword = keyword != null && !keyword.isBlank();
        boolean hasDept = department != null && !department.isBlank();
        boolean hasDate = dateStr != null && !dateStr.isBlank();

        if (hasKeyword) {
            return eventRepository.searchByKeyword(keyword.trim());
        }
        if (hasDept && hasDate) {
            LocalDateTime from = LocalDate.parse(dateStr).atStartOfDay();
            return eventRepository.findByDepartmentIgnoreCaseAndDateGreaterThanEqual(department.trim(), from);
        }
        if (hasDept) {
            return eventRepository.findByDepartmentIgnoreCase(department.trim());
        }
        if (hasDate) {
            LocalDateTime from = LocalDate.parse(dateStr).atStartOfDay();
            return eventRepository.findByDateGreaterThanEqual(from);
        }
        return eventRepository.findUpcomingEvents(LocalDateTime.now());
    }

    @Transactional(readOnly = true)
    public List<Event> findUpcoming() {
        return eventRepository.findUpcomingEvents(LocalDateTime.now());
    }

    @Transactional(readOnly = true)
    public List<EventStatsDto> getRegistrationStats() {
        List<Object[]> rows = eventRepository.findRegistrationCountPerEvent();

        Map<Long, Integer> capacityMap = new HashMap<>();
        eventRepository.findAll().forEach(e -> capacityMap.put(e.getId(), e.getCapacity()));

        List<EventStatsDto> stats = new ArrayList<>();
        for (Object[] row : rows) {
            Long eventId = (Long) row[0];
            String title = (String) row[1];
            long count = (Long) row[2];
            int cap = capacityMap.getOrDefault(eventId, 0);
            stats.add(new EventStatsDto(eventId, title, count, cap));
        }
        return stats;
    }

    @Transactional(readOnly = true)
    public long getTotalRegistrations() {
        return eventRepository.countTotalRegistrations();
    }

    @Transactional(readOnly = true)
    public long getTotalEvents() {
        return eventRepository.count();
    }

    @Transactional(readOnly = true)
    public List<Object[]> getEventsByDepartment() {
        return eventRepository.countEventsByDepartment();
    }
}

package com.campus.events.dto;

public class EventStatsDto {

    private Long eventId;
    private String eventTitle;
    private long registrationCount;
    private int capacity;

    public EventStatsDto(Long eventId, String eventTitle, long registrationCount, int capacity) {
        this.eventId = eventId;
        this.eventTitle = eventTitle;
        this.registrationCount = registrationCount;
        this.capacity = capacity;
    }

    public Long getEventId() { return eventId; }
    public String getEventTitle() { return eventTitle; }
    public long getRegistrationCount() { return registrationCount; }
    public int getCapacity() { return capacity; }

    public void setEventId(Long eventId) { this.eventId = eventId; }
    public void setEventTitle(String eventTitle) { this.eventTitle = eventTitle; }
    public void setRegistrationCount(long registrationCount) { this.registrationCount = registrationCount; }
    public void setCapacity(int capacity) { this.capacity = capacity; }

    public double fillPercentage() {
        if (capacity == 0) return 0.0;
        return Math.round((registrationCount * 100.0 / capacity) * 10.0) / 10.0;
    }
}

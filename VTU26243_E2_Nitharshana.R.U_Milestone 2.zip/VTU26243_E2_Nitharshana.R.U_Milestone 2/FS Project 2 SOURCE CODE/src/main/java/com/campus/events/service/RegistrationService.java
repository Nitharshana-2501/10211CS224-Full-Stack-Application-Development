package com.campus.events.service;

import com.campus.events.entity.Event;
import com.campus.events.entity.Registration;
import com.campus.events.exception.EventNotFoundException;
import com.campus.events.exception.RegistrationException;
import com.campus.events.repository.EventRepository;
import com.campus.events.repository.RegistrationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.logging.Logger;

@Service
public class RegistrationService {

    private static final Logger logger = Logger.getLogger(RegistrationService.class.getName());

    @Autowired
    private RegistrationRepository registrationRepository;

    @Autowired
    private EventRepository eventRepository;

    @Transactional
    public Registration register(Long eventId, Registration registration) {
        Event event = eventRepository.findById(eventId)
                .orElseThrow(() -> new EventNotFoundException(eventId));

        if (registrationRepository.existsByStudentEmailIgnoreCaseAndEventId(
                registration.getStudentEmail(), eventId)) {
            throw new RegistrationException(
                    "You are already registered for this event: " + event.getTitle());
        }

        if (!event.hasAvailableSeats()) {
            throw new RegistrationException(
                    "Sorry, this event is fully booked: " + event.getTitle());
        }

        registration.setEvent(event);
        Registration saved = registrationRepository.save(registration);
        logger.info("Student '" + registration.getStudentEmail() + "' registered for event id=" + eventId);
        return saved;
    }

    @Transactional(readOnly = true)
    public List<Registration> findByStudentEmail(String email) {
        return registrationRepository.findByStudentEmailIgnoreCase(email);
    }

    @Transactional(readOnly = true)
    public List<Registration> findByEventId(Long eventId) {
        return registrationRepository.findByEventId(eventId);
    }

    @Transactional
    public void cancelRegistration(Long registrationId) {
        if (!registrationRepository.existsById(registrationId)) {
            throw new RegistrationException("Registration not found with id: " + registrationId);
        }
        registrationRepository.deleteById(registrationId);
        logger.info("Cancelled registration id=" + registrationId);
    }

    @Transactional(readOnly = true)
    public long countByEventId(Long eventId) {
        return registrationRepository.countByEventId(eventId);
    }
}

package com.campus.events.repository;

import com.campus.events.entity.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface EventRepository extends JpaRepository<Event, Long> {

    // -------------------------------------------------------
    // Search / Filter queries
    // -------------------------------------------------------

    /** Find events by department (case-insensitive). */
    List<Event> findByDepartmentIgnoreCase(String department);

    /** Find events on or after a given date. */
    List<Event> findByDateGreaterThanEqual(LocalDateTime date);

    /** Find events by department AND on or after a given date. */
    List<Event> findByDepartmentIgnoreCaseAndDateGreaterThanEqual(
            String department, LocalDateTime date);

    /** Full-text search across title and description. */
    @Query("SELECT e FROM Event e WHERE " +
           "LOWER(e.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(e.description) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Event> searchByKeyword(@Param("keyword") String keyword);

    /** Upcoming events ordered by date ascending. */
    @Query("SELECT e FROM Event e WHERE e.date >= :now ORDER BY e.date ASC")
    List<Event> findUpcomingEvents(@Param("now") LocalDateTime now);

    // -------------------------------------------------------
    // Admin dashboard aggregate queries
    // -------------------------------------------------------

    /**
     * Returns [eventId, eventTitle, registrationCount] for all events,
     * ordered by registration count descending.
     */
    @Query("SELECT e.id, e.title, COUNT(r.id) AS regCount " +
           "FROM Event e LEFT JOIN e.registrations r " +
           "GROUP BY e.id, e.title " +
           "ORDER BY regCount DESC")
    List<Object[]> findRegistrationCountPerEvent();

    /**
     * Returns the total number of registrations across all events.
     */
    @Query("SELECT COUNT(r) FROM Registration r")
    long countTotalRegistrations();

    /**
     * Returns [department, eventCount] pairs.
     */
    @Query("SELECT e.department, COUNT(e) FROM Event e GROUP BY e.department ORDER BY e.department")
    List<Object[]> countEventsByDepartment();
}

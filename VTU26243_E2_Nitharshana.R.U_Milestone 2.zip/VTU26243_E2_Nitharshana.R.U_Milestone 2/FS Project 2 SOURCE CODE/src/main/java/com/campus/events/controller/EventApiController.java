package com.campus.events.controller;

import com.campus.events.entity.Event;
import com.campus.events.entity.Registration;
import com.campus.events.service.EventService;
import com.campus.events.service.RegistrationService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST API endpoints — useful for AJAX calls or external consumers.
 * Base path: /api/v1
 */
@RestController
@RequestMapping("/api/v1")
public class EventApiController {

    @Autowired
    private EventService eventService;

    @Autowired
    private RegistrationService registrationService;

    // -------------------------------------------------------
    // Events
    // -------------------------------------------------------

    @GetMapping("/events")
    public ResponseEntity<List<Event>> getAllEvents(
            @RequestParam(required = false) String department,
            @RequestParam(required = false) String date,
            @RequestParam(required = false) String keyword) {
        return ResponseEntity.ok(eventService.search(department, date, keyword));
    }

    @GetMapping("/events/{id}")
    public ResponseEntity<Event> getEvent(@PathVariable Long id) {
        return ResponseEntity.ok(eventService.findById(id));
    }

    @PostMapping("/events")
    public ResponseEntity<Event> createEvent(@Valid @RequestBody Event event) {
        return ResponseEntity.status(HttpStatus.CREATED).body(eventService.save(event));
    }

    @PutMapping("/events/{id}")
    public ResponseEntity<Event> updateEvent(
            @PathVariable Long id,
            @Valid @RequestBody Event event) {
        return ResponseEntity.ok(eventService.update(id, event));
    }

    @DeleteMapping("/events/{id}")
    public ResponseEntity<Void> deleteEvent(@PathVariable Long id) {
        eventService.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // -------------------------------------------------------
    // Registrations
    // -------------------------------------------------------

    @PostMapping("/events/{id}/registrations")
    public ResponseEntity<Registration> register(
            @PathVariable Long id,
            @Valid @RequestBody Registration registration) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(registrationService.register(id, registration));
    }

    @GetMapping("/registrations")
    public ResponseEntity<List<Registration>> getMyRegistrations(
            @RequestParam String email) {
        return ResponseEntity.ok(registrationService.findByStudentEmail(email));
    }
}

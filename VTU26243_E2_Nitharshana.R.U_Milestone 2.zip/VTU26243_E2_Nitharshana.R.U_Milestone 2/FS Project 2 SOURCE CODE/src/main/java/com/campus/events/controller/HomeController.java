package com.campus.events.controller;

import java.util.List;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.campus.events.entity.Event;
import com.campus.events.entity.Registration;
import com.campus.events.service.EventService;
import com.campus.events.service.RegistrationService;

import jakarta.validation.Valid;

@Controller
public class HomeController {

    private static final Logger logger = Logger.getLogger(HomeController.class.getName());

    @Autowired
    private EventService eventService;

    @Autowired
    private RegistrationService registrationService;

    @GetMapping("/")
    public String home(
            @RequestParam(required = false) String department,
            @RequestParam(required = false) String date,
            @RequestParam(required = false) String keyword,
            Model model) {

        List<Event> events = eventService.search(department, date, keyword);
        model.addAttribute("events", events);
        model.addAttribute("department", department);
        model.addAttribute("date", date);
        model.addAttribute("keyword", keyword);
        model.addAttribute("eventTypes", Event.EventType.values());
        return "index";
    }

    @GetMapping("/events/{id}")
    public String eventDetail(@PathVariable Long id, Model model) {
        Event event = eventService.findById(id);
        model.addAttribute("event", event);
        model.addAttribute("registration", new Registration());
        model.addAttribute("registrationCount", registrationService.countByEventId(id));
        return "event-detail";
    }

    @GetMapping("/events/{id}/register")
    public String showRegistrationForm(@PathVariable Long id, Model model) {
        Event event = eventService.findById(id);
        model.addAttribute("event", event);
        model.addAttribute("registration", new Registration());
        return "register";
    }

    @PostMapping("/events/{id}/register")
    public String submitRegistration(
            @PathVariable Long id,
            @Valid @ModelAttribute("registration") Registration registration,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            model.addAttribute("event", eventService.findById(id));
            return "register";
        }

        registrationService.register(id, registration);
        redirectAttributes.addFlashAttribute("successMessage",
                "You have successfully registered for the event!");
        return "redirect:/my-registrations?email=" + registration.getStudentEmail();
    }

    @GetMapping("/my-registrations")
    public String myRegistrations(
            @RequestParam(required = false) String email,
            Model model) {

        if (email != null && !email.isBlank()) {
            List<Registration> registrations = registrationService.findByStudentEmail(email);
            model.addAttribute("registrations", registrations);
            model.addAttribute("email", email);
        }
        return "my-registrations";
    }
}

@echo off
echo ========================================
echo   STARTING SUBSCRIPTION ENGINE
echo ========================================

REM Set environment variables
set "JAVA_HOME=C:\Program Files\Eclipse Adoptium\jdk-25.0.2.10-hotspot"
set "MAVEN_HOME=D:\apache-maven-3.9.12-bin\apache-maven-3.9.12"

echo JAVA_HOME: %JAVA_HOME%
echo MAVEN_HOME: %MAVEN_HOME%
echo.

REM Check if we're in the right directory
if not exist "pom.xml" (
    echo ERROR: pom.xml not found! Please run from project root directory.
    pause
    exit /b 1
)

echo Starting Spring Boot application...
echo Application will be available at: http://localhost:8080
echo.
echo Available API endpoints:
echo   GET  /api/subscriptions/tiers
echo   POST /api/auth/signup  
echo   POST /api/auth/signin
echo.
echo Press Ctrl+C to stop the application
echo.

REM Run the application
"%MAVEN_HOME%\bin\mvn.cmd" spring-boot:run

pause
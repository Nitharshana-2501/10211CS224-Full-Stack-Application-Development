-- Simple Database Setup for VS Code Development
-- Execute this in MySQL Workbench or command line: mysql -u root -p < database/setup.sql

DROP DATABASE IF EXISTS membership_db;
CREATE DATABASE membership_db;
USE membership_db;

-- Users table
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    phone_number VARCHAR(20),
    is_active BOOLEAN DEFAULT TRUE,
    email_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- User roles table
CREATE TABLE user_roles (
    user_id BIGINT NOT NULL,
    role VARCHAR(20) NOT NULL,
    PRIMARY KEY (user_id, role),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Subscriptions table
CREATE TABLE subscriptions (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL,
    tier ENUM('BASIC', 'PREMIUM', 'ENTERPRISE') NOT NULL,
    status ENUM('ACTIVE', 'CANCELLED', 'EXPIRED', 'SUSPENDED', 'PENDING') NOT NULL,
    billing_cycle ENUM('WEEKLY', 'MONTHLY', 'QUARTERLY', 'YEARLY') DEFAULT 'MONTHLY',
    start_date TIMESTAMP NOT NULL,
    end_date TIMESTAMP NOT NULL,
    next_billing_date TIMESTAMP NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    auto_renew BOOLEAN DEFAULT TRUE,
    trial_end_date TIMESTAMP NULL,
    cancelled_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Sample admin user (username: admin, password: admin123)
INSERT INTO users (username, email, password, first_name, last_name, is_active, email_verified) VALUES 
('admin', 'admin@test.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'Admin', 'User', TRUE, TRUE);

INSERT INTO user_roles (user_id, role) VALUES (1, 'ADMIN'), (1, 'USER');

-- Sample regular user (username: testuser, password: password123)
INSERT INTO users (username, email, password, first_name, last_name) VALUES 
('testuser', 'test@test.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 'Test', 'User');

INSERT INTO user_roles (user_id, role) VALUES (2, 'USER');

-- Sample subscription
INSERT INTO subscriptions (user_id, tier, status, start_date, end_date, next_billing_date, amount, billing_cycle) VALUES 
(2, 'BASIC', 'ACTIVE', NOW(), DATE_ADD(NOW(), INTERVAL 1 MONTH), DATE_ADD(NOW(), INTERVAL 1 MONTH), 9.99, 'MONTHLY');

SELECT 'Database setup complete!' as message;
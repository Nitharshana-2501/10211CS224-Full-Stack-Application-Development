// auth.js - depends on app.js being loaded first

document.addEventListener('DOMContentLoaded', function () {
    if (isAuthenticated()) {
        window.location.href = '/dashboard.html';
        return;
    }
    var loginForm = document.getElementById('loginForm');
    if (loginForm) loginForm.addEventListener('submit', handleLogin);

    var registerForm = document.getElementById('registerForm');
    if (registerForm) registerForm.addEventListener('submit', handleRegister);
});

async function handleLogin(e) {
    e.preventDefault();

    var username = document.getElementById('username').value.trim();
    var password = document.getElementById('password').value;

    if (!username || !password) {
        showAlert('Please fill in all fields.', 'error');
        return;
    }

    var btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'Logging in...';

    try {
        var res = await fetch('/api/auth/signin', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: username, password: password })
        });

        var text = await res.text();
        var data = {};
        try { data = JSON.parse(text); } catch(e) {}

        if (res.ok && data.accessToken) {
            setAuthToken(data.accessToken);
            showAlert('Login successful! Redirecting...', 'success');
            setTimeout(function () { window.location.href = '/dashboard.html'; }, 800);
        } else {
            showAlert(data.message || 'Invalid username or password.', 'error');
            btn.disabled = false;
            btn.textContent = 'Login';
        }
    } catch (err) {
        console.error('Login error:', err);
        showAlert('Server error. Please try again.', 'error');
        btn.disabled = false;
        btn.textContent = 'Login';
    }
}

async function handleRegister(e) {
    e.preventDefault();

    var firstName = document.getElementById('firstName').value.trim();
    var lastName  = document.getElementById('lastName').value.trim();
    var username  = document.getElementById('username').value.trim();
    var email     = document.getElementById('email').value.trim();
    var password  = document.getElementById('password').value;

    if (!firstName || !lastName || !username || !email || !password) {
        showAlert('Please fill in all fields.', 'error');
        return;
    }
    if (password.length < 6) {
        showAlert('Password must be at least 6 characters.', 'error');
        return;
    }

    var btn = e.target.querySelector('button[type="submit"]');
    btn.disabled = true;
    btn.textContent = 'Creating account...';

    try {
        // Step 1: Register
        var regRes = await fetch('/api/auth/signup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                firstName: firstName,
                lastName: lastName,
                username: username,
                email: email,
                password: password
            })
        });

        var regText = await regRes.text();
        var regData = {};
        try { regData = JSON.parse(regText); } catch(e) {}

        if (!regRes.ok) {
            showAlert(regData.message || 'Registration failed. Username or email may already exist.', 'error');
            btn.disabled = false;
            btn.textContent = 'Create Account';
            return;
        }

        showAlert('Account created! Logging you in...', 'success');

        // Step 2: Auto-login
        var loginRes = await fetch('/api/auth/signin', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: username, password: password })
        });

        var loginText = await loginRes.text();
        var loginData = {};
        try { loginData = JSON.parse(loginText); } catch(e) {}

        if (loginRes.ok && loginData.accessToken) {
            setAuthToken(loginData.accessToken);
            setTimeout(function () { window.location.href = '/dashboard.html'; }, 800);
        } else {
            showAlert('Account created! Please login.', 'success');
            setTimeout(function () { window.location.href = '/login.html'; }, 1500);
        }

    } catch (err) {
        console.error('Register error:', err);
        showAlert('Server error. Please try again.', 'error');
        btn.disabled = false;
        btn.textContent = 'Create Account';
    }
}

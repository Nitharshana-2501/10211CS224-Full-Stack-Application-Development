// Use relative URL - works regardless of port or hostname
const API_BASE_URL = '/api';

// Load subscription tiers on homepage
document.addEventListener('DOMContentLoaded', function () {
    if (isAuthenticated() && document.getElementById('pricingGrid')) {
        const navLinks = document.querySelector('.nav-links');
        if (navLinks) {
            navLinks.innerHTML = `
                <a href="/dashboard.html" class="nav-link">Dashboard</a>
                <a href="#" class="nav-link btn-primary" onclick="removeAuthToken();window.location.href='/';">Logout</a>
            `;
        }
    }
    if (document.getElementById('pricingGrid')) {
        loadSubscriptionTiers();
    }
});

async function loadSubscriptionTiers() {
    try {
        const response = await fetch(API_BASE_URL + '/subscriptions/tiers');
        const tiers = await response.json();
        const pricingGrid = document.getElementById('pricingGrid');
        pricingGrid.innerHTML = '';

        const tierDetails = {
            'BASIC': {
                price: 'Rs. 799',
                features: ['Basic Features', 'Email Support', '1 User Account', 'Monthly Billing']
            },
            'PREMIUM': {
                price: 'Rs. 1,599',
                features: ['All Basic Features', 'Priority Support', '5 User Accounts', 'Advanced Analytics', 'Monthly/Yearly Billing']
            },
            'ENTERPRISE': {
                price: 'Rs. 3,999',
                features: ['All Premium Features', '24/7 Phone Support', 'Unlimited Users', 'Custom Integrations', 'Dedicated Account Manager']
            }
        };

        tiers.forEach(function (tier) {
            const details = tierDetails[tier];
            const isPopular = tier === 'PREMIUM';
            const card = document.createElement('div');
            card.className = 'pricing-card' + (isPopular ? ' featured' : '');
            card.innerHTML =
                (isPopular ? '<div class="featured-badge">Most Popular</div>' : '') +
                '<div class="plan-name">' + tier + '</div>' +
                '<div class="plan-price">' + details.price + '</div>' +
                '<div class="plan-period">per month</div>' +
                '<div class="plan-divider"></div>' +
                '<ul class="plan-features">' +
                details.features.map(function (f) { return '<li>' + f + '</li>'; }).join('') +
                '</ul>' +
                '<a href="/register.html" class="btn' + (isPopular ? '' : ' btn-outline') + '">Get Started</a>';
            pricingGrid.appendChild(card);
        });
    } catch (error) {
        console.error('Error loading tiers:', error);
        var grid = document.getElementById('pricingGrid');
        if (grid) grid.innerHTML = '<p>Error loading plans. Please refresh.</p>';
    }
}

// ---------- Utility functions ----------

function showAlert(message, type) {
    type = type || 'success';
    var alertEl = document.getElementById('alert');
    if (!alertEl) return;
    alertEl.className = 'alert alert-' + type;
    alertEl.textContent = message;
    alertEl.style.display = 'block';
    setTimeout(function () { alertEl.style.display = 'none'; }, 5000);
}

function getAuthToken() {
    return localStorage.getItem('authToken');
}

function setAuthToken(token) {
    localStorage.setItem('authToken', token);
}

function removeAuthToken() {
    localStorage.removeItem('authToken');
}

function isAuthenticated() {
    return !!getAuthToken();
}

async function apiCall(endpoint, options) {
    options = options || {};
    var token = getAuthToken();
    var headers = { 'Content-Type': 'application/json' };
    if (options.headers) {
        Object.assign(headers, options.headers);
    }
    if (token) {
        headers['Authorization'] = 'Bearer ' + token;
    }
    var fetchOptions = Object.assign({}, options, { headers: headers });
    var response = await fetch(API_BASE_URL + endpoint, fetchOptions);
    if (response.status === 401) {
        removeAuthToken();
        window.location.href = '/login.html';
        return null;
    }
    return response;
}

// Dashboard JavaScript
document.addEventListener('DOMContentLoaded', function() {
    if (!isAuthenticated()) {
        window.location.href = '/login.html';
        return;
    }
    loadUserProfile();
    loadSubscriptionInfo();
    loadAvailablePlans();
    setupEventListeners();
});

function setupEventListeners() {
    document.getElementById('logoutBtn').addEventListener('click', handleLogout);
    document.getElementById('editProfileBtn').addEventListener('click', showEditProfileModal);
    document.getElementById('cancelEditBtn').addEventListener('click', hideEditProfileModal);
    document.getElementById('editProfileForm').addEventListener('submit', handleEditProfile);
    document.getElementById('changePasswordBtn').addEventListener('click', showChangePasswordModal);
    document.getElementById('cancelPasswordBtn').addEventListener('click', hideChangePasswordModal);
    document.getElementById('changePasswordForm').addEventListener('submit', handleChangePassword);
    document.getElementById('cancelSubscriptionBtn').addEventListener('click', handleCancelSubscription);
}

async function loadUserProfile() {
    try {
        const response = await apiCall('/users/me');
        if (!response || !response.ok) return;
        const user = await response.json();

        document.getElementById('userWelcome').textContent = `Hi, ${user.firstName || user.username}!`;
        document.getElementById('userName').textContent = `${user.firstName || ''} ${user.lastName || ''}`.trim();
        document.getElementById('userEmail').textContent = user.email;
        document.getElementById('userUsername').textContent = user.username;

        document.getElementById('editFirstName').value = user.firstName || '';
        document.getElementById('editLastName').value = user.lastName || '';
        document.getElementById('editPhoneNumber').value = user.phoneNumber || '';
    } catch (error) {
        console.error('Error loading profile:', error);
    }
}

async function loadSubscriptionInfo() {
    const subscriptionInfo = document.getElementById('subscriptionInfo');
    const subscriptionActions = document.getElementById('subscriptionActions');

    try {
        const response = await apiCall('/subscriptions/me');

        if (!response) return;

        if (response.ok) {
            const sub = await response.json();
            const tierPrices = { BASIC: 'Rs. 799', PREMIUM: 'Rs. 1,599', ENTERPRISE: 'Rs. 3,999' };
            const badgeClass = sub.status === 'ACTIVE' ? 'badge-active' : 'badge-cancelled';

            subscriptionInfo.innerHTML = `
                <div class="sub-tier">${sub.tier}</div>
                <span class="sub-badge ${badgeClass}">${sub.status}</span>
                <div class="sub-detail"><strong>Price:</strong> ${tierPrices[sub.tier] || ''}/month</div>
                <div class="sub-detail"><strong>Billing:</strong> ${sub.billingCycle}</div>
                <div class="sub-detail"><strong>Started:</strong> ${new Date(sub.startDate).toLocaleDateString('en-IN')}</div>
                <div class="sub-detail"><strong>Renews:</strong> ${new Date(sub.nextBillingDate).toLocaleDateString('en-IN')}</div>
                <div class="sub-detail"><strong>Days Left:</strong> ${sub.daysRemaining}</div>
            `;

            if (sub.status === 'ACTIVE') {
                const upgrades = ['BASIC', 'PREMIUM', 'ENTERPRISE'].filter(t => t !== sub.tier);
                subscriptionActions.innerHTML = upgrades.map(t =>
                    `<button onclick="upgradeSubscription('${t}')" class="action-btn">Upgrade to ${t}</button>`
                ).join('');
            } else {
                subscriptionActions.innerHTML = '<p class="sub-detail" style="color:#f87171;">Subscription inactive. Choose a plan below.</p>';
            }
        } else if (response.status === 404) {
            subscriptionInfo.innerHTML = '<p class="sub-detail">No active subscription.</p>';
            subscriptionActions.innerHTML = '<p class="sub-detail">Pick a plan below to get started!</p>';
        } else {
            subscriptionInfo.innerHTML = '<p class="sub-detail" style="color:#f87171;">Could not load subscription.</p>';
        }
    } catch (error) {
        console.error('Error loading subscription:', error);
        subscriptionInfo.innerHTML = '<p style="color:#dc3545;">Error loading subscription.</p>';
    }
}

async function loadAvailablePlans() {
    try {
        const response = await fetch(`${API_BASE_URL}/subscriptions/tiers`);
        const tiers = await response.json();
        const tierDetails = {
            BASIC:      { price: 'Rs. 799',   color: '#28a745', features: 'Basic features, Email support' },
            PREMIUM:    { price: 'Rs. 1,599', color: '#007bff', features: 'All Basic + Priority support, Analytics' },
            ENTERPRISE: { price: 'Rs. 3,999', color: '#6f42c1', features: 'All Premium + 24/7 support, Unlimited users' }
        };

        document.getElementById('availablePlans').innerHTML = tiers.map(tier => `
            <div class="plan-option">
                <div class="plan-option-name">${tier}</div>
                <div class="plan-option-price">${tierDetails[tier].price}/month &mdash; ${tierDetails[tier].features}</div>
                <button onclick="createSubscription('${tier}')" class="action-btn">Subscribe</button>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error loading plans:', error);
    }
}

async function createSubscription(tier) {
    window.location.href = '/payment.html?tier=' + tier;
}

async function upgradeSubscription(newTier) {
    window.location.href = '/payment.html?tier=' + newTier;
}


async function handleCancelSubscription() {
    if (!confirm('Are you sure you want to cancel your subscription?')) return;
    try {
        const response = await apiCall('/subscriptions/cancel', { method: 'PUT' });
        if (!response) return;
        if (response.ok) {
            showAlert('Subscription cancelled.', 'success');
            loadSubscriptionInfo();
        } else {
            const err = await response.json().catch(() => ({}));
            showAlert(err.message || 'Failed to cancel.', 'error');
        }
    } catch (error) {
        showAlert('Error cancelling subscription.', 'error');
    }
}

function handleLogout() {
    removeAuthToken();
    window.location.href = '/';
}

function showEditProfileModal() { document.getElementById('editProfileModal').classList.add('open'); }
function hideEditProfileModal() { document.getElementById('editProfileModal').classList.remove('open'); }
function showChangePasswordModal() { document.getElementById('changePasswordModal').classList.add('open'); }
function hideChangePasswordModal() {
    document.getElementById('changePasswordModal').classList.remove('open');
    document.getElementById('changePasswordForm').reset();
}

async function handleEditProfile(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    try {
        const response = await apiCall('/users/me', {
            method: 'PUT',
            body: JSON.stringify({
                firstName: formData.get('firstName'),
                lastName: formData.get('lastName'),
                phoneNumber: formData.get('phoneNumber')
            })
        });
        if (!response) return;
        if (response.ok) {
            showAlert('Profile updated!', 'success');
            hideEditProfileModal();
            loadUserProfile();
        } else {
            const err = await response.json().catch(() => ({}));
            showAlert(err.message || 'Failed to update profile.', 'error');
        }
    } catch (error) {
        showAlert('Error updating profile.', 'error');
    }
}

async function handleChangePassword(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const newPassword = formData.get('newPassword');
    const confirmPassword = formData.get('confirmPassword');

    if (newPassword !== confirmPassword) {
        showAlert('Passwords do not match.', 'error');
        return;
    }
    try {
        const response = await apiCall('/users/me/password', {
            method: 'PUT',
            body: JSON.stringify({ oldPassword: formData.get('oldPassword'), newPassword })
        });
        if (!response) return;
        if (response.ok) {
            showAlert('Password changed!', 'success');
            hideChangePasswordModal();
        } else {
            const err = await response.json().catch(() => ({}));
            showAlert(err.message || 'Failed to change password.', 'error');
        }
    } catch (error) {
        showAlert('Error changing password.', 'error');
    }
}

package com.membership.service;

import com.membership.model.*;
import com.membership.repository.SubscriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.math.BigDecimal;

@Service
public class SubscriptionService {
    
    @Autowired
    private SubscriptionRepository subscriptionRepository;
    
    public Subscription createSubscription(User user, MembershipTier tier) {
        return createSubscription(user, tier, BillingCycle.MONTHLY);
    }
    
    public Subscription createSubscription(User user, MembershipTier tier, BillingCycle billingCycle) {
        // Check if user already has an active subscription
        Optional<Subscription> existingSubscription = subscriptionRepository.findByUserId(user.getId());
        if (existingSubscription.isPresent() && existingSubscription.get().isActive()) {
            throw new RuntimeException("User already has an active subscription");
        }
        
        Subscription subscription = new Subscription(user, tier, billingCycle);
        return subscriptionRepository.save(subscription);
    }
    
    public Subscription upgradeSubscription(Long userId, MembershipTier newTier) {
        Optional<Subscription> subscriptionOpt = subscriptionRepository.findByUserId(userId);
        if (subscriptionOpt.isEmpty()) {
            throw new RuntimeException("No subscription found for user");
        }
        
        Subscription subscription = subscriptionOpt.get();
        if (!subscription.isActive()) {
            throw new RuntimeException("Cannot upgrade inactive subscription");
        }
        
        subscription.setTier(newTier);
        subscription.setAmount(BigDecimal.valueOf(newTier.getMonthlyPrice()));
        return subscriptionRepository.save(subscription);
    }
    
    public Subscription cancelSubscription(Long userId) {
        Optional<Subscription> subscriptionOpt = subscriptionRepository.findByUserId(userId);
        if (subscriptionOpt.isEmpty()) {
            throw new RuntimeException("No subscription found for user");
        }
        
        Subscription subscription = subscriptionOpt.get();
        subscription.cancel();
        return subscriptionRepository.save(subscription);
    }
    
    public Subscription suspendSubscription(Long userId) {
        Optional<Subscription> subscriptionOpt = subscriptionRepository.findByUserId(userId);
        if (subscriptionOpt.isEmpty()) {
            throw new RuntimeException("No subscription found for user");
        }
        
        Subscription subscription = subscriptionOpt.get();
        subscription.suspend();
        return subscriptionRepository.save(subscription);
    }
    
    public Subscription reactivateSubscription(Long userId) {
        Optional<Subscription> subscriptionOpt = subscriptionRepository.findByUserId(userId);
        if (subscriptionOpt.isEmpty()) {
            throw new RuntimeException("No subscription found for user");
        }
        
        Subscription subscription = subscriptionOpt.get();
        subscription.reactivate();
        return subscriptionRepository.save(subscription);
    }
    
    public Subscription renewSubscription(Long subscriptionId) {
        Optional<Subscription> subscriptionOpt = subscriptionRepository.findById(subscriptionId);
        if (subscriptionOpt.isEmpty()) {
            throw new RuntimeException("Subscription not found");
        }
        
        Subscription subscription = subscriptionOpt.get();
        subscription.renewSubscription();
        return subscriptionRepository.save(subscription);
    }
    
    public List<Subscription> getSubscriptionsDueForBilling() {
        return subscriptionRepository.findSubscriptionsDueForBilling(LocalDateTime.now());
    }
    
    public List<Subscription> getExpiredSubscriptions() {
        return subscriptionRepository.findExpiredSubscriptions(LocalDateTime.now());
    }
    
    public Optional<Subscription> getUserSubscription(Long userId) {
        return subscriptionRepository.findByUserId(userId);
    }
    
    public boolean hasAccess(Long userId, String feature) {
        Optional<Subscription> subscriptionOpt = subscriptionRepository.findByUserId(userId);
        if (subscriptionOpt.isEmpty() || !subscriptionOpt.get().isActive()) {
            return false;
        }
        
        MembershipTier tier = subscriptionOpt.get().getTier();
        return checkFeatureAccess(tier, feature);
    }
    
    public List<Subscription> getAllSubscriptions() {
        return subscriptionRepository.findAll();
    }
    
    public List<Subscription> getSubscriptionsByTier(MembershipTier tier) {
        return subscriptionRepository.findByTier(tier);
    }
    
    public List<Subscription> getSubscriptionsByStatus(SubscriptionStatus status) {
        return subscriptionRepository.findByStatus(status);
    }
    
    private boolean checkFeatureAccess(MembershipTier tier, String feature) {
        switch (feature.toLowerCase()) {
            case "basic_features":
                return true; // All tiers have basic features
            case "premium_features":
                return tier == MembershipTier.PREMIUM || tier == MembershipTier.ENTERPRISE;
            case "enterprise_features":
                return tier == MembershipTier.ENTERPRISE;
            case "api_access":
                return tier == MembershipTier.PREMIUM || tier == MembershipTier.ENTERPRISE;
            case "advanced_analytics":
                return tier == MembershipTier.ENTERPRISE;
            case "priority_support":
                return tier == MembershipTier.PREMIUM || tier == MembershipTier.ENTERPRISE;
            case "custom_integrations":
                return tier == MembershipTier.ENTERPRISE;
            default:
                return false;
        }
    }
}
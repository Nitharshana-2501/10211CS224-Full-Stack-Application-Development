package com.membership.model;

public enum MembershipTier {
    BASIC("Basic", 9.99, 1, 5, 1),
    PREMIUM("Premium", 19.99, 5, 20, 3),
    ENTERPRISE("Enterprise", 49.99, -1, -1, 10); // -1 means unlimited
    
    private final String displayName;
    private final double monthlyPrice;
    private final int maxProjects;
    private final int maxUsers;
    private final int supportLevel;
    
    MembershipTier(String displayName, double monthlyPrice, int maxProjects, int maxUsers, int supportLevel) {
        this.displayName = displayName;
        this.monthlyPrice = monthlyPrice;
        this.maxProjects = maxProjects;
        this.maxUsers = maxUsers;
        this.supportLevel = supportLevel;
    }
    
    // Getters
    public String getDisplayName() { return displayName; }
    public double getMonthlyPrice() { return monthlyPrice; }
    public int getMaxProjects() { return maxProjects; }
    public int getMaxUsers() { return maxUsers; }
    public int getSupportLevel() { return supportLevel; }
}
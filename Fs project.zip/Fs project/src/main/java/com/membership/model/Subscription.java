package com.membership.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.math.BigDecimal;

@Entity
@Table(name = "subscriptions")
public class Subscription {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @OneToOne
    @JoinColumn(name = "user_id")
    private User user;
    
    @Enumerated(EnumType.STRING)
    private MembershipTier tier;
    
    @Enumerated(EnumType.STRING)
    private SubscriptionStatus status;
    
    @Column(name = "start_date")
    private LocalDateTime startDate;
    
    @Column(name = "end_date")
    private LocalDateTime endDate;
    
    @Column(name = "next_billing_date")
    private LocalDateTime nextBillingDate;
    
    @Column(precision = 10, scale = 2)
    private BigDecimal amount;
    
    @Column(name = "billing_cycle")
    @Enumerated(EnumType.STRING)
    private BillingCycle billingCycle = BillingCycle.MONTHLY;
    
    @Column(name = "auto_renew")
    private Boolean autoRenew = true;
    
    @Column(name = "trial_end_date")
    private LocalDateTime trialEndDate;
    
    @Column(name = "cancelled_at")
    private LocalDateTime cancelledAt;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    // Constructors
    public Subscription() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }
    
    public Subscription(User user, MembershipTier tier) {
        this();
        this.user = user;
        this.tier = tier;
        this.status = SubscriptionStatus.ACTIVE;
        this.startDate = LocalDateTime.now();
        this.endDate = calculateEndDate(billingCycle);
        this.nextBillingDate = endDate;
        this.amount = BigDecimal.valueOf(tier.getMonthlyPrice());
    }
    
    public Subscription(User user, MembershipTier tier, BillingCycle billingCycle) {
        this(user, tier);
        this.billingCycle = billingCycle;
        this.endDate = calculateEndDate(billingCycle);
        this.nextBillingDate = endDate;
        this.amount = calculateAmount(tier, billingCycle);
    }
    
    // Business methods
    public boolean isActive() {
        return status == SubscriptionStatus.ACTIVE && LocalDateTime.now().isBefore(endDate);
    }
    
    public boolean isInTrial() {
        return trialEndDate != null && LocalDateTime.now().isBefore(trialEndDate);
    }
    
    public boolean isExpired() {
        return LocalDateTime.now().isAfter(endDate);
    }
    
    public void renewSubscription() {
        if (status == SubscriptionStatus.ACTIVE) {
            this.startDate = this.endDate;
            this.endDate = calculateEndDate(billingCycle);
            this.nextBillingDate = endDate;
            this.updatedAt = LocalDateTime.now();
        }
    }
    
    public void cancel() {
        this.status = SubscriptionStatus.CANCELLED;
        this.cancelledAt = LocalDateTime.now();
        this.autoRenew = false;
        this.updatedAt = LocalDateTime.now();
    }
    
    public void suspend() {
        this.status = SubscriptionStatus.SUSPENDED;
        this.updatedAt = LocalDateTime.now();
    }
    
    public void reactivate() {
        this.status = SubscriptionStatus.ACTIVE;
        this.updatedAt = LocalDateTime.now();
    }
    
    public long getDaysRemaining() {
        if (isActive()) {
            return java.time.temporal.ChronoUnit.DAYS.between(LocalDateTime.now(), endDate);
        }
        return 0;
    }
    
    private LocalDateTime calculateEndDate(BillingCycle cycle) {
        LocalDateTime start = startDate != null ? startDate : LocalDateTime.now();
        switch (cycle) {
            case WEEKLY:
                return start.plusWeeks(1);
            case MONTHLY:
                return start.plusMonths(1);
            case QUARTERLY:
                return start.plusMonths(3);
            case YEARLY:
                return start.plusYears(1);
            default:
                return start.plusMonths(1);
        }
    }
    
    private BigDecimal calculateAmount(MembershipTier tier, BillingCycle cycle) {
        BigDecimal basePrice = BigDecimal.valueOf(tier.getMonthlyPrice());
        switch (cycle) {
            case WEEKLY:
                return basePrice.multiply(BigDecimal.valueOf(0.25));
            case MONTHLY:
                return basePrice;
            case QUARTERLY:
                return basePrice.multiply(BigDecimal.valueOf(3)).multiply(BigDecimal.valueOf(0.95)); // 5% discount
            case YEARLY:
                return basePrice.multiply(BigDecimal.valueOf(12)).multiply(BigDecimal.valueOf(0.85)); // 15% discount
            default:
                return basePrice;
        }
    }
    
    @PreUpdate
    public void preUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }
    
    public MembershipTier getTier() { return tier; }
    public void setTier(MembershipTier tier) { this.tier = tier; }
    
    public SubscriptionStatus getStatus() { return status; }
    public void setStatus(SubscriptionStatus status) { this.status = status; }
    
    public LocalDateTime getStartDate() { return startDate; }
    public void setStartDate(LocalDateTime startDate) { this.startDate = startDate; }
    
    public LocalDateTime getEndDate() { return endDate; }
    public void setEndDate(LocalDateTime endDate) { this.endDate = endDate; }
    
    public LocalDateTime getNextBillingDate() { return nextBillingDate; }
    public void setNextBillingDate(LocalDateTime nextBillingDate) { this.nextBillingDate = nextBillingDate; }
    
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    
    public BillingCycle getBillingCycle() { return billingCycle; }
    public void setBillingCycle(BillingCycle billingCycle) { this.billingCycle = billingCycle; }
    
    public Boolean getAutoRenew() { return autoRenew; }
    public void setAutoRenew(Boolean autoRenew) { this.autoRenew = autoRenew; }
    
    public LocalDateTime getTrialEndDate() { return trialEndDate; }
    public void setTrialEndDate(LocalDateTime trialEndDate) { this.trialEndDate = trialEndDate; }
    
    public LocalDateTime getCancelledAt() { return cancelledAt; }
    public void setCancelledAt(LocalDateTime cancelledAt) { this.cancelledAt = cancelledAt; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}
package com.membership.model;

public enum BillingCycle {
    WEEKLY("Weekly", 7),
    MONTHLY("Monthly", 30),
    QUARTERLY("Quarterly", 90),
    YEARLY("Yearly", 365);
    
    private final String displayName;
    private final int days;
    
    BillingCycle(String displayName, int days) {
        this.displayName = displayName;
        this.days = days;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    public int getDays() {
        return days;
    }
}
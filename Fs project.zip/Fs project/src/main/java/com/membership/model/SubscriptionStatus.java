package com.membership.model;

public enum SubscriptionStatus {
    ACTIVE,
    CANCELLED,
    EXPIRED,
    SUSPENDED,
    PENDING
}
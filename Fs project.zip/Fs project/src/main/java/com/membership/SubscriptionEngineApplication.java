package com.membership;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SubscriptionEngineApplication {
    public static void main(String[] args) {
        SpringApplication.run(SubscriptionEngineApplication.class, args);
        System.out.println("🚀 Subscription Engine Started Successfully!");
        System.out.println("📡 API available at: http://localhost:8080");
        System.out.println("📋 Test endpoints:");
        System.out.println("   GET  /api/subscriptions/tiers");
        System.out.println("   POST /api/auth/signup");
        System.out.println("   POST /api/auth/signin");
    }
}
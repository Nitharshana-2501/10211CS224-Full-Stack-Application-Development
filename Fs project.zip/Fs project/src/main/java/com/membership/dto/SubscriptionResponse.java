package com.membership.dto;

import com.membership.model.Subscription;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class SubscriptionResponse {
    private Long id;
    private String tier;
    private String status;
    private String billingCycle;
    private BigDecimal amount;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private LocalDateTime nextBillingDate;
    private long daysRemaining;
    private Boolean autoRenew;

    public static SubscriptionResponse from(Subscription s) {
        SubscriptionResponse r = new SubscriptionResponse();
        r.id = s.getId();
        r.tier = s.getTier().name();
        r.status = s.getStatus().name();
        r.billingCycle = s.getBillingCycle().name();
        r.amount = s.getAmount();
        r.startDate = s.getStartDate();
        r.endDate = s.getEndDate();
        r.nextBillingDate = s.getNextBillingDate();
        r.daysRemaining = s.getDaysRemaining();
        r.autoRenew = s.getAutoRenew();
        return r;
    }

    public Long getId() { return id; }
    public String getTier() { return tier; }
    public String getStatus() { return status; }
    public String getBillingCycle() { return billingCycle; }
    public BigDecimal getAmount() { return amount; }
    public LocalDateTime getStartDate() { return startDate; }
    public LocalDateTime getEndDate() { return endDate; }
    public LocalDateTime getNextBillingDate() { return nextBillingDate; }
    public long getDaysRemaining() { return daysRemaining; }
    public Boolean getAutoRenew() { return autoRenew; }
}
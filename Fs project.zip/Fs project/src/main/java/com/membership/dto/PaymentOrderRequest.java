package com.membership.dto;

public class PaymentOrderRequest {
    private String tier;
    private String billingCycle;

    public String getTier() { return tier; }
    public void setTier(String tier) { this.tier = tier; }
    public String getBillingCycle() { return billingCycle; }
    public void setBillingCycle(String billingCycle) { this.billingCycle = billingCycle; }
}
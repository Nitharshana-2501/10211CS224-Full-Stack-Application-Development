package com.membership.dto;

import com.membership.model.User;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.stream.Collectors;

public class UserResponse {
    private Long id;
    private String username;
    private String email;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private Boolean isActive;
    private LocalDateTime createdAt;
    private Set<String> roles;

    public static UserResponse from(User u) {
        UserResponse r = new UserResponse();
        r.id          = u.getId();
        r.username    = u.getUsername();
        r.email       = u.getEmail();
        r.firstName   = u.getFirstName();
        r.lastName    = u.getLastName();
        r.phoneNumber = u.getPhoneNumber();
        r.isActive    = u.getIsActive();
        r.createdAt   = u.getCreatedAt();
        r.roles       = u.getRoles() == null ? null :
                        u.getRoles().stream().map(Enum::name).collect(Collectors.toSet());
        return r;
    }

    public Long getId()            { return id; }
    public String getUsername()    { return username; }
    public String getEmail()       { return email; }
    public String getFirstName()   { return firstName; }
    public String getLastName()    { return lastName; }
    public String getPhoneNumber() { return phoneNumber; }
    public Boolean getIsActive()   { return isActive; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public Set<String> getRoles()  { return roles; }
}
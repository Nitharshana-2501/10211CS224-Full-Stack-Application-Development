package com.membership.controller;

import com.membership.dto.SubscriptionResponse;
import com.membership.model.BillingCycle;
import com.membership.model.MembershipTier;
import com.membership.model.Subscription;
import com.membership.model.User;
import com.membership.security.UserPrincipal;
import com.membership.service.SubscriptionService;
import com.membership.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;
import java.util.Map;

@RestController
@RequestMapping("/api/subscriptions")
public class SubscriptionController {

    @Autowired
    private SubscriptionService subscriptionService;

    @Autowired
    private UserService userService;

    @PostMapping("/create")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> createSubscription(
            @RequestParam MembershipTier tier,
            @RequestParam(required = false) BillingCycle billingCycle,
            Authentication authentication) {
        try {
            UserPrincipal up = (UserPrincipal) authentication.getPrincipal();
            Optional<User> userOpt = userService.findById(up.getId());
            if (userOpt.isEmpty()) return ResponseEntity.notFound().build();
            BillingCycle cycle = billingCycle != null ? billingCycle : BillingCycle.MONTHLY;
            Subscription sub = subscriptionService.createSubscription(userOpt.get(), tier, cycle);
            return ResponseEntity.ok(SubscriptionResponse.from(sub));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    @PutMapping("/upgrade")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> upgradeSubscription(@RequestParam MembershipTier newTier, Authentication authentication) {
        try {
            UserPrincipal up = (UserPrincipal) authentication.getPrincipal();
            Subscription sub = subscriptionService.upgradeSubscription(up.getId(), newTier);
            return ResponseEntity.ok(SubscriptionResponse.from(sub));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    @PutMapping("/cancel")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> cancelSubscription(Authentication authentication) {
        try {
            UserPrincipal up = (UserPrincipal) authentication.getPrincipal();
            Subscription sub = subscriptionService.cancelSubscription(up.getId());
            return ResponseEntity.ok(SubscriptionResponse.from(sub));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    @GetMapping("/me")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> getMySubscription(Authentication authentication) {
        UserPrincipal up = (UserPrincipal) authentication.getPrincipal();
        Optional<Subscription> sub = subscriptionService.getUserSubscription(up.getId());
        return sub.map(s -> ResponseEntity.ok(SubscriptionResponse.from(s)))
                  .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/access")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<Boolean> checkMyAccess(@RequestParam String feature, Authentication authentication) {
        UserPrincipal up = (UserPrincipal) authentication.getPrincipal();
        return ResponseEntity.ok(subscriptionService.hasAccess(up.getId(), feature));
    }

    @GetMapping("/tiers")
    public ResponseEntity<MembershipTier[]> getAllTiers() {
        return ResponseEntity.ok(MembershipTier.values());
    }

    @GetMapping("/billing-cycles")
    public ResponseEntity<BillingCycle[]> getAllBillingCycles() {
        return ResponseEntity.ok(BillingCycle.values());
    }
}
package com.membership.controller;

import com.membership.dto.UserResponse;
import com.membership.model.User;
import com.membership.service.UserService;
import com.membership.security.UserPrincipal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import java.util.Optional;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/me")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> getCurrentUser(Authentication authentication) {
        UserPrincipal up = (UserPrincipal) authentication.getPrincipal();
        Optional<User> user = userService.findById(up.getId());
        return user.map(u -> ResponseEntity.ok(UserResponse.from(u)))
                   .orElse(ResponseEntity.notFound().build());
    }

    @PutMapping("/me")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> updateCurrentUser(@RequestBody Map<String, String> body,
                                               Authentication authentication) {
        try {
            UserPrincipal up = (UserPrincipal) authentication.getPrincipal();
            Optional<User> userOpt = userService.findById(up.getId());
            if (userOpt.isEmpty()) return ResponseEntity.notFound().build();
            User user = userOpt.get();
            if (body.containsKey("firstName"))   user.setFirstName(body.get("firstName"));
            if (body.containsKey("lastName"))    user.setLastName(body.get("lastName"));
            if (body.containsKey("phoneNumber")) user.setPhoneNumber(body.get("phoneNumber"));
            User updated = userService.updateUser(user);
            return ResponseEntity.ok(UserResponse.from(updated));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }

    @PutMapping("/me/password")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> changePassword(@RequestBody Map<String, String> body,
                                            Authentication authentication) {
        try {
            UserPrincipal up = (UserPrincipal) authentication.getPrincipal();
            userService.updatePassword(up.getId(), body.get("oldPassword"), body.get("newPassword"));
            return ResponseEntity.ok(Map.of("message", "Password updated successfully"));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("message", e.getMessage()));
        }
    }
}
package com.membership.controller;

import com.membership.dto.PaymentOrderRequest;
import com.membership.dto.SubscriptionResponse;
import com.membership.model.*;
import com.membership.security.UserPrincipal;
import com.membership.service.SubscriptionService;
import com.membership.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    @Value("${razorpay.key.id:rzp_test_placeholder}")
    private String razorpayKeyId;

    @Value("${razorpay.key.secret:placeholder_secret}")
    private String razorpayKeySecret;

    @Autowired
    private SubscriptionService subscriptionService;

    @Autowired
    private UserService userService;

    private static final Map<String, Integer> TIER_PRICES = new HashMap<>();
    static {
        TIER_PRICES.put("BASIC", 79900);
        TIER_PRICES.put("PREMIUM", 159900);
        TIER_PRICES.put("ENTERPRISE", 399900);
    }

    @PostMapping("/create-order")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> createOrder(@RequestBody PaymentOrderRequest req,
                                         Authentication authentication) {
        try {
            String tier = req.getTier().toUpperCase();
            Integer amountPaise = TIER_PRICES.get(tier);
            if (amountPaise == null) {
                return ResponseEntity.badRequest().body(Map.of("message", "Invalid tier: " + tier));
            }

            String receiptId = "rcpt_" + UUID.randomUUID().toString().replace("-", "").substring(0, 16);

            Map<String, Object> orderData = new HashMap<>();
            orderData.put("amount", amountPaise);
            orderData.put("currency", "INR");
            orderData.put("receipt", receiptId);
            orderData.put("tier", tier);
            orderData.put("billingCycle", req.getBillingCycle() != null ? req.getBillingCycle() : "MONTHLY");
            orderData.put("keyId", razorpayKeyId);

            try {
                com.razorpay.RazorpayClient razorpay = new com.razorpay.RazorpayClient(razorpayKeyId, razorpayKeySecret);
                org.json.JSONObject options = new org.json.JSONObject();
                options.put("amount", amountPaise);
                options.put("currency", "INR");
                options.put("receipt", receiptId);
                com.razorpay.Order order = razorpay.orders.create(options);
                orderData.put("orderId", order.get("id"));
            } catch (Exception e) {
                orderData.put("orderId", "order_" + receiptId);
                orderData.put("sdkError", e.getMessage());
            }

            return ResponseEntity.ok(orderData);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("message", e.getMessage()));
        }
    }

    @PostMapping("/verify")
    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<?> verifyPayment(@RequestBody Map<String, String> payload,
                                           Authentication authentication) {
        try {
            String razorpayOrderId = payload.get("razorpay_order_id");
            String razorpayPaymentId = payload.get("razorpay_payment_id");
            String razorpaySignature = payload.get("razorpay_signature");
            String tier = payload.get("tier");
            String billingCycle = payload.getOrDefault("billingCycle", "MONTHLY");

            boolean isValid = verifySignature(razorpayOrderId, razorpayPaymentId, razorpaySignature);
            if (!isValid) {
                return ResponseEntity.badRequest().body(Map.of("message", "Payment verification failed"));
            }

            UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
            Optional<User> userOpt = userService.findById(userPrincipal.getId());
            if (userOpt.isEmpty()) {
                return ResponseEntity.notFound().build();
            }

            MembershipTier membershipTier = MembershipTier.valueOf(tier.toUpperCase());
            BillingCycle cycle = BillingCycle.valueOf(billingCycle.toUpperCase());

            Optional<Subscription> existing = subscriptionService.getUserSubscription(userPrincipal.getId());
            Subscription subscription;
            if (existing.isPresent() && existing.get().isActive()) {
                subscription = subscriptionService.upgradeSubscription(userPrincipal.getId(), membershipTier);
            } else {
                subscription = subscriptionService.createSubscription(userOpt.get(), membershipTier, cycle);
            }

            return ResponseEntity.ok(SubscriptionResponse.from(subscription));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(Map.of("message", e.getMessage()));
        }
    }

    private boolean verifySignature(String orderId, String paymentId, String signature) {
        try {
            String data = orderId + "|" + paymentId;
            javax.crypto.Mac mac = javax.crypto.Mac.getInstance("HmacSHA256");
            mac.init(new javax.crypto.spec.SecretKeySpec(razorpayKeySecret.getBytes(), "HmacSHA256"));
            byte[] hash = mac.doFinal(data.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString().equals(signature);
        } catch (Exception e) {
            return false;
        }
    }
}
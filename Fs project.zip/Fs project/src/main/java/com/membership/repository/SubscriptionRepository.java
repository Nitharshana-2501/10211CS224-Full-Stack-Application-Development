package com.membership.repository;

import com.membership.model.Subscription;
import com.membership.model.SubscriptionStatus;
import com.membership.model.MembershipTier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {
    Optional<Subscription> findByUserId(Long userId);
    List<Subscription> findByStatus(SubscriptionStatus status);
    List<Subscription> findByTier(MembershipTier tier);
    
    @Query("SELECT s FROM Subscription s WHERE s.nextBillingDate <= :date AND s.status = 'ACTIVE'")
    List<Subscription> findSubscriptionsDueForBilling(LocalDateTime date);
    
    @Query("SELECT s FROM Subscription s WHERE s.endDate <= :date AND s.status = 'ACTIVE'")
    List<Subscription> findExpiredSubscriptions(LocalDateTime date);
}
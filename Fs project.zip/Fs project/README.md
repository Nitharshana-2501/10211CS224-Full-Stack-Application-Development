# Subscription Membership Engine - VS Code Project

A complete subscription-based membership system built with Spring Boot, MySQL, and JWT authentication.

## 🚀 Quick Setup

### 1. Prerequisites
- **Java 17+**
- **MySQL 8.0+** 
- **VS Code** with Java Extension Pack
- **Maven** (included with Java extensions)

### 2. VS Code Extensions (Required)
- Extension Pack for Java (Microsoft)
- Spring Boot Extension Pack (VMware)
- REST Client (Huachao Mao)

### 3. Database Setup
```bash
mysql -u root -p < database/setup.sql
```

### 4. Configuration
Update `src/main/resources/application.properties`:
```properties
spring.datasource.password=your_mysql_password
```

### 5. Run Application
- Press `F5` in VS Code
- Or use Command Palette: `Java: Run`
- Or terminal: `mvn spring-boot:run`

## 📡 API Testing

Open `api-tests.http` and use VS Code REST Client to test endpoints.

### Test Accounts
- **Admin:** `admin` / `admin123`
- **User:** `testuser` / `password123`

### Key Endpoints
- `GET /api/subscriptions/tiers` - Get membership tiers
- `POST /api/auth/signup` - Register user
- `POST /api/auth/signin` - Login user
- `POST /api/subscriptions/create` - Create subscription
- `GET /api/subscriptions/me` - Get my subscription

## 🏗️ Project Structure
```
src/main/java/com/membership/
├── config/          # Security configuration
├── controller/      # REST API endpoints
├── dto/            # Data transfer objects
├── model/          # Entity classes
├── repository/     # Data access layer
├── security/       # JWT & authentication
└── service/        # Business logic
```

## 🎯 Features
- JWT Authentication & Authorization
- Role-based Access Control (USER, ADMIN)
- Tiered Subscriptions (Basic $9.99, Premium $19.99, Enterprise $49.99)
- Multiple Billing Cycles (Weekly, Monthly, Quarterly, Yearly)
- Feature-based Access Control
- Password Encryption (BCrypt)
- Complete REST API

## 🔧 Development
- **Hot Reload:** Enabled with Spring Boot DevTools
- **Debug:** Use VS Code breakpoints (F5)
- **Test API:** Use `api-tests.http` file
- **Logs:** View in VS Code terminal

## 📊 Membership Tiers
| Tier | Price | Features |
|------|-------|----------|
| Basic | $9.99/month | Basic features, 1 project, 5 users |
| Premium | $19.99/month | Premium features, 5 projects, 20 users |
| Enterprise | $49.99/month | All features, unlimited projects/users |

Ready to develop! 🎉